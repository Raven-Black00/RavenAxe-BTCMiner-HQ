
import zipfile, os

src = "/home/user/release/RavenMiner_HQ_v5.0.5"
zip_path = "/home/user/release/RavenMiner_HQ_v5.0.5.zip"

files = [
    "Ravenminer_HQ_5.0.5.py",
    "README.md",
    "CHANGELOG.md",
    "Release-Notes.md",
    "installation.md",
    "requirements.txt",
]

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for fname in files:
        full = os.path.join(src, fname)
        # Store inside a top-level folder matching the zip name (GitHub convention)
        zf.write(full, arcname=f"RavenMiner_HQ_v5.0.5/{fname}")

# Summary
print(f"{'File':<40} {'Size':>10}")
print("─" * 52)
total = 0
with zipfile.ZipFile(zip_path) as zf:
    for info in zf.infolist():
        print(f"{info.filename:<40} {info.file_size:>10,} B")
        total += info.file_size

zip_size = os.path.getsize(zip_path)
print("─" * 52)
print(f"{'Uncompressed total':<40} {total:>10,} B")
print(f"{'ZIP file size':<40} {zip_size:>10,} B")
print(f"{'Compression ratio':<40} {(1 - zip_size/total)*100:>9.1f} %")
